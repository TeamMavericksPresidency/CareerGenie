import React from "react";

const QUESTION_DATA = [
  {
    question: <span>Who is not in our group</span>,
    answers: [
      <span> Rahul</span>,
      <span>Asmaa</span>,
      <span>Harpreet</span>,
      <span>Raho</span>,
    ],
    correct: 3,
  },
  {
    question: <span>Who is not in our group1</span>,
    answers: [
      <span> Rahul1</span>,
      <span>Asmaa1</span>,
      <span>Harpreet1</span>,
      <span>Raho1</span>,
    ],
    correct: 3,
  },
  {
    question: <span>Who is not in our group2</span>,
    answers: [
      <span> Rahul2</span>,
      <span>Asmaa2</span>,
      <span>Harpreet2</span>,
      <span>Raho2</span>,
    ],
    correct: 3,
  },
];

export default QUESTION_DATA;
