import React from "react";
import SideNav from "./SideNav";

export default function Dashboard() {
  return (
    <div>

     <SideNav />

    </div>
  );
}
